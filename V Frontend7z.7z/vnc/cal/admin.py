from django.contrib import admin
from .models import calc, res


# Register your models here.
class calAdmin(admin.ModelAdmin):
    list_display=('Name','consultant','specilization','complexity')
admin.site.register(calc,calAdmin)

class resAdmin(admin.ModelAdmin):
    list_display=('consultant','specilization','Efficiency')
admin.site.register(res,resAdmin)
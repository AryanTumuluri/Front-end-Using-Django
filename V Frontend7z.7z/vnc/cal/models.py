from django.db import models

# Create your models here.
class calc(models.Model):
    Name=models.CharField(max_length=250)
    consultant=models.CharField(max_length=250)
    specilization=models.CharField(max_length=250)
    complexity=models.CharField(max_length=250)

class res(models.Model):
    consultant=models.CharField(max_length=250)
    specilization=models.CharField(max_length=250)
    Efficiency=models.CharField(max_length=250)

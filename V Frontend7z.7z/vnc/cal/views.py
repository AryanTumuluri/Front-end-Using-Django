from django.shortcuts import render
from django.http import HttpResponse
from .models import calc, res

 
# Create your views here.
def index(request):
    obj=calc.objects.values('specilization').distinct()
    cname=request.POST.get('spec')
    char=cname
    obj1=calc.objects.values('consultant').filter(specilization=char).distinct()
    #dname=request.POST.get('doc')
    #obj2=res.objects.values('Efficiency').filter(consultant=dname).distinct()
    dname=request.POST.get('doc')
    obj2=res.objects.values('Efficiency').filter(consultant=dname)
    return render(request,'web1.html',{'obj':obj, 'obj1':obj1, 'obj2':obj2,'speciliz':cname,'doctor':dname})


#def new(request):
    #obj1=calc.objects.values('consultant').distinct()
    #return render(request,'index.html',{'obj1':obj1})

#def doctor(request):
   # dname=request.POST.get('doc')
   # obj2=res.objects.values('Efficiency').filter(consultant=dname)
   # return render(request, 'index.html',{'obj2':obj2})
    